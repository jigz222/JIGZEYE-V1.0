JIGZEYE AI CHART ANALYZER V1.0 — iPhone installation

FILES
- index.html: the app
- manifest.json: install metadata
- sw.js: offline app-shell cache
- icon-180.png and icon-512.png: app icons

PUBLISH FREE WITH GITHUB PAGES (iPhone only)
1. Open github.com in Safari and sign in.
2. Open the repository you already created.
3. Tap Add file → Upload files.
4. Upload ALL five files from this folder. The main file must be named exactly index.html and must be in the repository root (not inside another folder).
5. Commit the changes.
6. Open Settings → Pages.
7. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
8. Wait for deployment. In Settings → Pages, tap Visit site. GitHub says publishing can take up to 10 minutes.
9. In Safari, open the published https://...github.io/... address. Tap Share → Add to Home Screen → Add.

IMPORTANT
- A free GitHub Pages site from a public repository is publicly accessible. Do not upload private information or screenshots into the repository.
- The app itself does not upload selected chart screenshots; image analysis runs in the browser.
- iOS may show a slightly different Add to Home Screen flow depending on iOS version.
- This version is a pixel-colour heuristic prototype, not a trained AI model or a source of verified trading probabilities.
